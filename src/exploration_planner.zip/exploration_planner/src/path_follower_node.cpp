/**
 * Path Follower Node
 * 
 * Yaw injection yapılmış path'i takip eder.
 * 
 * Input:
 *   /exploration/path_with_yaw (nav_msgs/Path) - Yaw eklenmiş path
 *   /odom (nav_msgs/Odometry) - Mevcut pozisyon
 * 
 * Output:
 *   /cmd_vel (geometry_msgs/Twist) - Hız komutları
 * 
 * Özellikler:
 *   - Pure pursuit benzeri lookahead tracking
 *   - Smooth velocity control with rate limiting
 *   - Height control for drones
 *   - Slowdown near goal
 */

#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/path.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include "exploration_planner/math_utils.hpp"

namespace exploration_planner
{

class PathFollowerNode : public rclcpp::Node
{
public:
  PathFollowerNode() : Node("path_follower_node")
  {
    // Motion limits
    declare_parameter("v_max", 2.5);
    declare_parameter("yaw_rate_max", 3.0);
    declare_parameter("a_max", 0.7);
    declare_parameter("yaw_accel_max", 1.0);
    
    // Control gains
    declare_parameter("kp_pos", 0.8);
    declare_parameter("kp_yaw", 1.2);
    declare_parameter("kp_z", 1.0);
    
    // Height control
    declare_parameter("target_height", 1.5);
    declare_parameter("height_tolerance", 0.2);
    declare_parameter("vz_max", 1.0);
    
    // Path following
    declare_parameter("lookahead_distance", 0.5);
    declare_parameter("goal_tolerance_xy", 0.25);
    declare_parameter("goal_tolerance_yaw", 0.15);
    declare_parameter("waypoint_tolerance", 0.5);
    
    // Smoothing
    declare_parameter("control_rate", 30.0);
    declare_parameter("velocity_smoothing", 0.3);
    declare_parameter("slowdown_distance", 2.0);
    declare_parameter("min_approach_speed", 0.3);
    
    loadParameters();
    
    // Subscribers
    path_sub_ = create_subscription<nav_msgs::msg::Path>(
      "/exploration/path_with_yaw", 10,
      std::bind(&PathFollowerNode::pathCallback, this, std::placeholders::_1));
    
    odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
      "/odom", rclcpp::SensorDataQoS(),
      std::bind(&PathFollowerNode::odomCallback, this, std::placeholders::_1));
    
    // Publisher
    cmd_pub_ = create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);
    
    // Control timer
    control_timer_ = create_wall_timer(
      std::chrono::duration<double>(dt_),
      std::bind(&PathFollowerNode::controlLoop, this));
    
    RCLCPP_INFO(get_logger(), "Path Follower Node initialized");
    RCLCPP_INFO(get_logger(), "  v_max: %.1f m/s, yaw_rate_max: %.1f rad/s",
                v_max_, yaw_rate_max_);
    RCLCPP_INFO(get_logger(), "  lookahead: %.2f m, goal_tol: %.2f m",
                lookahead_dist_, goal_tolerance_xy_);
  }

private:
  void loadParameters()
  {
    v_max_ = get_parameter("v_max").as_double();
    yaw_rate_max_ = get_parameter("yaw_rate_max").as_double();
    a_max_ = get_parameter("a_max").as_double();
    yaw_accel_max_ = get_parameter("yaw_accel_max").as_double();
    kp_pos_ = get_parameter("kp_pos").as_double();
    kp_yaw_ = get_parameter("kp_yaw").as_double();
    kp_z_ = get_parameter("kp_z").as_double();
    target_height_ = get_parameter("target_height").as_double();
    height_tolerance_ = get_parameter("height_tolerance").as_double();
    vz_max_ = get_parameter("vz_max").as_double();
    lookahead_dist_ = get_parameter("lookahead_distance").as_double();
    goal_tolerance_xy_ = get_parameter("goal_tolerance_xy").as_double();
    goal_tolerance_yaw_ = get_parameter("goal_tolerance_yaw").as_double();
    waypoint_tolerance_ = get_parameter("waypoint_tolerance").as_double();
    double rate = get_parameter("control_rate").as_double();
    dt_ = 1.0 / rate;
    velocity_smoothing_ = get_parameter("velocity_smoothing").as_double();
    slowdown_distance_ = get_parameter("slowdown_distance").as_double();
    min_approach_speed_ = get_parameter("min_approach_speed").as_double();
  }
  
  void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    current_pose_ = msg->pose.pose;
    have_odom_ = true;
  }
  
  void pathCallback(const nav_msgs::msg::Path::SharedPtr msg)
  {
    if (msg->poses.empty()) {
      RCLCPP_WARN(get_logger(), "Received empty path");
      have_path_ = false;
      return;
    }
    
    current_path_ = *msg;
    path_index_ = 0;
    have_path_ = true;
    
    // Final hedefi sakla
    goal_pose_ = msg->poses.back().pose;
    
    RCLCPP_INFO(get_logger(), "New path received: %zu poses", msg->poses.size());
  }
  
  void controlLoop()
  {
    geometry_msgs::msg::Twist cmd;
    
    if (!have_odom_ || !have_path_) {
      cmd = smoothStop();
      cmd_pub_->publish(cmd);
      return;
    }
    
    // Hedefe olan mesafe
    double dist_to_goal = distance2D(current_pose_.position, goal_pose_.position);
    
    // Hedefe ulaştık mı?
    if (dist_to_goal < goal_tolerance_xy_) {
      handleGoalReached(cmd);
      cmd_pub_->publish(cmd);
      return;
    }
    
    // Lookahead noktasını bul
    updatePathIndex();
    
    if (path_index_ >= current_path_.poses.size()) {
      cmd = smoothStop();
      cmd_pub_->publish(cmd);
      return;
    }
    
    // Tracking
    trackPath(cmd, dist_to_goal);
    
    cmd_pub_->publish(cmd);
    last_cmd_ = cmd;
  }
  
  void updatePathIndex()
  {
    // Mevcut waypoint'e ulaştık mı?
    while (path_index_ < current_path_.poses.size() - 1) {
      double dist = distance2D(
        current_pose_.position,
        current_path_.poses[path_index_].pose.position);
      
      if (dist > waypoint_tolerance_) break;
      path_index_++;
    }
  }
  
  void handleGoalReached(geometry_msgs::msg::Twist& cmd)
  {
    double current_yaw = getYaw(current_pose_.orientation);
    double target_yaw = getYaw(goal_pose_.orientation);
    double yaw_error = normalizeAngle(target_yaw - current_yaw);
    
    // Yaw kontrolü
    if (std::abs(yaw_error) > goal_tolerance_yaw_) {
      // Sadece dön
      cmd.angular.z = computeYawRate(yaw_error);
      cmd.linear.z = computeHeightControl();
      cmd = smoothVelocity(cmd);
      
      RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
                           "At position, rotating: yaw_err=%.1f°",
                           yaw_error * 180.0 / M_PI);
    } else {
      // Tamamen ulaştık
      cmd = smoothStop();
      cmd.linear.z = computeHeightControl();
      
      RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 2000,
                           "Goal reached!");
    }
  }
  
  void trackPath(geometry_msgs::msg::Twist& cmd, double dist_to_goal)
  {
    // Hedef waypoint
    const auto& target_wp = current_path_.poses[path_index_];
    
    // Pozisyon hatası
    double dx = target_wp.pose.position.x - current_pose_.position.x;
    double dy = target_wp.pose.position.y - current_pose_.position.y;
    double dist = std::sqrt(dx*dx + dy*dy);
    
    // Yaw hatası
    double current_yaw = getYaw(current_pose_.orientation);
    double desired_yaw = getYaw(target_wp.pose.orientation);
    double yaw_error = normalizeAngle(desired_yaw - current_yaw);
    
    // Body frame'e dönüştür
    double cos_yaw = std::cos(current_yaw);
    double sin_yaw = std::sin(current_yaw);
    double dx_body = cos_yaw * dx + sin_yaw * dy;
    double dy_body = -sin_yaw * dx + cos_yaw * dy;
    
    // Hız skalası
    double speed_scale = computeSpeedScale(dist_to_goal, yaw_error);
    
    // Hız komutları
    double desired_vx = kp_pos_ * dx_body * speed_scale;
    double desired_vy = kp_pos_ * dy_body * speed_scale;
    
    // Hız limitlemesi
    double v = std::sqrt(desired_vx*desired_vx + desired_vy*desired_vy);
    double max_v = v_max_ * speed_scale;
    
    if (v > max_v) {
      double scale = max_v / v;
      desired_vx *= scale;
      desired_vy *= scale;
    }
    
    // Rate limiting
    cmd.linear.x = rateLimitLinear(desired_vx, last_cmd_.linear.x);
    cmd.linear.y = rateLimitLinear(desired_vy, last_cmd_.linear.y);
    cmd.linear.z = computeHeightControl();
    cmd.angular.z = computeYawRate(yaw_error);
    
    // Smoothing
    cmd = smoothVelocity(cmd);
  }
  
  double computeSpeedScale(double dist_to_goal, double yaw_error)
  {
    double scale = 1.0;
    
    // Hedefe yakınken yavaşla
    if (dist_to_goal < slowdown_distance_) {
      scale = std::max(min_approach_speed_ / v_max_, dist_to_goal / slowdown_distance_);
    }
    
    // Yaw hatası büyükken yavaşla
    double yaw_factor = std::max(0.3, std::cos(yaw_error));
    scale *= yaw_factor;
    
    return scale;
  }
  
  double computeHeightControl()
  {
    double z_error = target_height_ - current_pose_.position.z;
    if (std::abs(z_error) > height_tolerance_) {
      return std::clamp(kp_z_ * z_error, -vz_max_, vz_max_);
    }
    return 0.0;
  }
  
  double computeYawRate(double yaw_error)
  {
    double desired_rate = kp_yaw_ * yaw_error;
    
    // Rate limiting
    double max_change = yaw_accel_max_ * dt_;
    double diff = desired_rate - last_cmd_.angular.z;
    
    double rate;
    if (std::abs(diff) > max_change) {
      rate = last_cmd_.angular.z + std::copysign(max_change, diff);
    } else {
      rate = desired_rate;
    }
    
    return std::clamp(rate, -yaw_rate_max_, yaw_rate_max_);
  }
  
  double rateLimitLinear(double desired, double current)
  {
    double max_change = a_max_ * dt_;
    double diff = desired - current;
    
    if (std::abs(diff) > max_change) {
      return current + std::copysign(max_change, diff);
    }
    return desired;
  }
  
  geometry_msgs::msg::Twist smoothVelocity(const geometry_msgs::msg::Twist& desired)
  {
    geometry_msgs::msg::Twist smoothed;
    double a = velocity_smoothing_;
    
    smoothed.linear.x = a * last_cmd_.linear.x + (1.0 - a) * desired.linear.x;
    smoothed.linear.y = a * last_cmd_.linear.y + (1.0 - a) * desired.linear.y;
    smoothed.linear.z = a * last_cmd_.linear.z + (1.0 - a) * desired.linear.z;
    smoothed.angular.z = a * last_cmd_.angular.z + (1.0 - a) * desired.angular.z;
    
    return smoothed;
  }
  
  geometry_msgs::msg::Twist smoothStop()
  {
    geometry_msgs::msg::Twist cmd;
    double decay = 0.8;
    
    cmd.linear.x = last_cmd_.linear.x * decay;
    cmd.linear.y = last_cmd_.linear.y * decay;
    cmd.linear.z = last_cmd_.linear.z * decay;
    cmd.angular.z = last_cmd_.angular.z * decay;
    
    auto zero = [](double& v) { if (std::abs(v) < 0.01) v = 0; };
    zero(cmd.linear.x);
    zero(cmd.linear.y);
    zero(cmd.linear.z);
    zero(cmd.angular.z);
    
    last_cmd_ = cmd;
    return cmd;
  }
  
  // Parameters
  double v_max_, yaw_rate_max_;
  double a_max_, yaw_accel_max_;
  double kp_pos_, kp_yaw_, kp_z_;
  double target_height_, height_tolerance_, vz_max_;
  double lookahead_dist_;
  double goal_tolerance_xy_, goal_tolerance_yaw_;
  double waypoint_tolerance_;
  double dt_;
  double velocity_smoothing_;
  double slowdown_distance_, min_approach_speed_;
  
  // State
  geometry_msgs::msg::Pose current_pose_;
  geometry_msgs::msg::Pose goal_pose_;
  nav_msgs::msg::Path current_path_;
  size_t path_index_ = 0;
  geometry_msgs::msg::Twist last_cmd_;
  bool have_odom_ = false;
  bool have_path_ = false;
  
  // ROS interfaces
  rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr path_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
  rclcpp::TimerBase::SharedPtr control_timer_;
};

}  // namespace exploration_planner

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<exploration_planner::PathFollowerNode>());
  rclcpp::shutdown();
  return 0;
}
