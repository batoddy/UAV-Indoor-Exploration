/**
 * Greedy Frontier Selector with Nav2 Integration
 * 
 * Frontier cluster'lardan en iyi viewpoint'i seçer ve Nav2'ye goal gönderir.
 * 
 * Input:
 *   /frontier_clusters_complete (frontier_exploration/FrontierArray)
 *   /odom veya /mavros/local_position/pose
 *   /global_costmap/costmap (optional) - risky target filtering
 * 
 * Output:
 *   /exploration/global_tour (ExplorationStatus) - Mevcut hedef bilgisi
 *   /exploration/target_pose (PoseStamped) - Yaw injection için hedef
 *   /frontier_clusters_scored (FrontierArray) - Debug/visualization
 * 
 * Nav2:
 *   NavigateToPose action ile goal gönderir
 */

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <std_srvs/srv/trigger.hpp>
#include <nav2_msgs/action/navigate_to_pose.hpp>

#include "frontier_exploration/msg/frontier_array.hpp"
#include "exploration_planner/msg/exploration_status.hpp"
#include "exploration_planner/math_utils.hpp"

#include <algorithm>
#include <vector>

namespace exploration_planner
{

class GlobalTourPlannerNode : public rclcpp::Node
{
public:
  using NavigateToPose = nav2_msgs::action::NavigateToPose;
  using GoalHandle = rclcpp_action::ClientGoalHandle<NavigateToPose>;

  GlobalTourPlannerNode() : Node("global_tour_planner")
  {
    declareParameters();
    loadParameters();
    
    // Subscribers
    clusters_sub_ = create_subscription<frontier_exploration::msg::FrontierArray>(
      "/frontier_clusters_complete", 10,
      std::bind(&GlobalTourPlannerNode::clustersCallback, this, std::placeholders::_1));
    
    odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
      "/odom", 10,
      std::bind(&GlobalTourPlannerNode::odomCallback, this, std::placeholders::_1));
    
    pose_sub_ = create_subscription<geometry_msgs::msg::PoseStamped>(
      "/mavros/local_position/pose", 10,
      std::bind(&GlobalTourPlannerNode::poseCallback, this, std::placeholders::_1));
    
    costmap_sub_ = create_subscription<nav_msgs::msg::OccupancyGrid>(
      "/global_costmap/costmap", rclcpp::QoS(1).transient_local(),
      [this](nav_msgs::msg::OccupancyGrid::SharedPtr msg) { costmap_ = msg; });
    
    // Publishers
    tour_pub_ = create_publisher<exploration_planner::msg::ExplorationStatus>(
      "/exploration/global_tour", 10);
    
    target_pub_ = create_publisher<geometry_msgs::msg::PoseStamped>(
      "/exploration/target_pose", 10);
    
    scored_pub_ = create_publisher<frontier_exploration::msg::FrontierArray>(
      "/frontier_clusters_scored", 10);
    
    // Services
    start_srv_ = create_service<std_srvs::srv::Trigger>(
      "/exploration/start",
      std::bind(&GlobalTourPlannerNode::startCallback, this,
                std::placeholders::_1, std::placeholders::_2));
    
    stop_srv_ = create_service<std_srvs::srv::Trigger>(
      "/exploration/stop",
      std::bind(&GlobalTourPlannerNode::stopCallback, this,
                std::placeholders::_1, std::placeholders::_2));
    
    // Nav2 action client
    nav_client_ = rclcpp_action::create_client<NavigateToPose>(this, nav2_action_name_);
    
    logInitialization();
  }

private:
  // ═══════════════════════════════════════════════════════════════════════════
  // PARAMETERS
  // ═══════════════════════════════════════════════════════════════════════════
  
  void declareParameters()
  {
    // Scoring weights
    declare_parameter("w_time", 1.0);
    declare_parameter("w_coverage", 1.0);
    declare_parameter("w_size", 0.2);
    declare_parameter("w_costmap", 0.0);
    
    // Scoring scales
    declare_parameter("coverage_scale", 50.0);
    declare_parameter("size_scale", 200.0);
    declare_parameter("time_scale", 5.0);
    declare_parameter("costmap_scale", 100.0);
    
    // Selection
    declare_parameter("max_viewpoints_per_cluster", 5);
    declare_parameter("top_k_targets", 3);
    declare_parameter("use_viewpoint_yaw", true);
    
    // Motion limits
    declare_parameter("v_max", 2.5);
    declare_parameter("yaw_rate_max", 3.0);
    
    // Hysteresis
    declare_parameter("hysteresis_enabled", true);
    declare_parameter("switch_margin", 0.15);
    
    // Costmap filtering
    declare_parameter("costmap_filter_enabled", false);
    declare_parameter("costmap_lethal_threshold", 65);
    
    // Nav2
    declare_parameter("nav2_enable", true);
    declare_parameter("nav2_action_name", "navigate_to_pose");
    declare_parameter("nav2_min_send_period", 1.0);
    declare_parameter("nav2_goal_position_tolerance", 0.5);
    declare_parameter("nav2_goal_yaw_tolerance", 0.35);
  }
  
  void loadParameters()
  {
    w_time_ = get_parameter("w_time").as_double();
    w_coverage_ = get_parameter("w_coverage").as_double();
    w_size_ = get_parameter("w_size").as_double();
    w_costmap_ = get_parameter("w_costmap").as_double();
    
    coverage_scale_ = std::max(1e-6, get_parameter("coverage_scale").as_double());
    size_scale_ = std::max(1e-6, get_parameter("size_scale").as_double());
    time_scale_ = std::max(1e-6, get_parameter("time_scale").as_double());
    costmap_scale_ = std::max(1e-6, get_parameter("costmap_scale").as_double());
    
    max_vp_per_cluster_ = get_parameter("max_viewpoints_per_cluster").as_int();
    top_k_ = std::max(1, get_parameter("top_k_targets").as_int());
    use_vp_yaw_ = get_parameter("use_viewpoint_yaw").as_bool();
    
    v_max_ = std::max(0.1, get_parameter("v_max").as_double());
    yaw_rate_max_ = std::max(0.1, get_parameter("yaw_rate_max").as_double());
    
    hysteresis_enabled_ = get_parameter("hysteresis_enabled").as_bool();
    switch_margin_ = get_parameter("switch_margin").as_double();
    
    costmap_filter_enabled_ = get_parameter("costmap_filter_enabled").as_bool();
    costmap_lethal_threshold_ = get_parameter("costmap_lethal_threshold").as_int();
    
    nav2_enable_ = get_parameter("nav2_enable").as_bool();
    nav2_action_name_ = get_parameter("nav2_action_name").as_string();
    nav2_min_period_ = get_parameter("nav2_min_send_period").as_double();
    nav2_pos_tol_ = get_parameter("nav2_goal_position_tolerance").as_double();
    nav2_yaw_tol_ = get_parameter("nav2_goal_yaw_tolerance").as_double();
  }
  
  void logInitialization()
  {
    RCLCPP_INFO(get_logger(), "Global Tour Planner initialized");
    RCLCPP_INFO(get_logger(), "  Weights: time=%.2f, cov=%.2f, size=%.2f",
                w_time_, w_coverage_, w_size_);
    RCLCPP_INFO(get_logger(), "  Top-K: %d, VP per cluster: %d", top_k_, max_vp_per_cluster_);
    RCLCPP_INFO(get_logger(), "  Nav2: %s", nav2_enable_ ? "ENABLED" : "DISABLED");
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SERVICES
  // ═══════════════════════════════════════════════════════════════════════════
  
  void startCallback(const std_srvs::srv::Trigger::Request::SharedPtr,
                     std_srvs::srv::Trigger::Response::SharedPtr response)
  {
    exploration_active_ = true;
    response->success = true;
    response->message = "Exploration started";
    RCLCPP_INFO(get_logger(), "Exploration STARTED");
  }
  
  void stopCallback(const std_srvs::srv::Trigger::Request::SharedPtr,
                    std_srvs::srv::Trigger::Response::SharedPtr response)
  {
    exploration_active_ = false;
    cancelNav2Goal();
    
    exploration_planner::msg::ExplorationStatus status;
    status.header.stamp = now();
    status.state = exploration_planner::msg::ExplorationStatus::IDLE;
    tour_pub_->publish(status);
    
    response->success = true;
    response->message = "Exploration stopped";
    RCLCPP_INFO(get_logger(), "Exploration STOPPED");
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CALLBACKS
  // ═══════════════════════════════════════════════════════════════════════════
  
  void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    current_pose_.header = msg->header;
    current_pose_.pose = msg->pose.pose;
    have_pose_ = true;
  }
  
  void poseCallback(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
  {
    if (!have_pose_) {
      current_pose_ = *msg;
      have_pose_ = true;
    }
  }
  
  void clustersCallback(const frontier_exploration::msg::FrontierArray::SharedPtr msg)
  {
    if (!exploration_active_ || !have_pose_) return;
    
    // Score all viewpoints
    auto candidates = scoreViewpoints(msg);
    
    if (candidates.empty()) {
      publishExplorationComplete(msg->header.frame_id);
      return;
    }
    
    // Select best targets
    auto targets = selectBestTargets(candidates);
    
    // Publish results
    publishTour(msg->header.frame_id, targets);
    publishTargetPose(msg->header.frame_id, targets.front());
    
    // Send Nav2 goal
    if (nav2_enable_) {
      sendNav2Goal(msg->header.frame_id, targets.front());
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SCORING
  // ═══════════════════════════════════════════════════════════════════════════
  
  struct Candidate
  {
    uint32_t cluster_id;
    int vp_index;
    double score;
    geometry_msgs::msg::Point position;
    double yaw;
    geometry_msgs::msg::Point centroid;
    uint32_t size;
    int coverage;
  };
  
  std::vector<Candidate> scoreViewpoints(
    const frontier_exploration::msg::FrontierArray::SharedPtr& msg)
  {
    std::vector<Candidate> candidates;
    candidates.reserve(256);
    
    auto cur_pos = current_pose_.pose.position;
    double cur_yaw = getYaw(current_pose_.pose.orientation);
    
    for (const auto& cluster : msg->clusters) {
      if (cluster.viewpoints.empty()) continue;
      
      int n_eval = std::min(static_cast<int>(cluster.viewpoints.size()), max_vp_per_cluster_);
      
      for (int i = 0; i < n_eval; ++i) {
        const auto& vp = cluster.viewpoints[i];
        
        // Costmap filtering
        if (costmap_filter_enabled_ && costmap_) {
          int cost = getCostmapValue(vp.position.x, vp.position.y);
          if (cost < 0 || cost >= costmap_lethal_threshold_) continue;
        }
        
        double score = computeScore(cluster, vp, cur_pos, cur_yaw);
        
        double yaw = use_vp_yaw_ ? vp.yaw : 
          std::atan2(cluster.centroid.y - vp.position.y, 
                     cluster.centroid.x - vp.position.x);
        
        candidates.push_back({
          cluster.id, i, score,
          vp.position, yaw,
          cluster.centroid, cluster.size, vp.coverage
        });
      }
    }
    
    return candidates;
  }
  
  double computeScore(
    const frontier_exploration::msg::FrontierCluster& cluster,
    const frontier_exploration::msg::Viewpoint& vp,
    const geometry_msgs::msg::Point& cur_pos,
    double cur_yaw)
  {
    // Distance and time cost
    double dist = distance2D(cur_pos, vp.position);
    double target_yaw = use_vp_yaw_ ? vp.yaw :
      std::atan2(cluster.centroid.y - vp.position.y,
                 cluster.centroid.x - vp.position.x);
    double yaw_diff = angleDiff(cur_yaw, target_yaw);
    
    double t_trans = dist / v_max_;
    double t_yaw = yaw_diff / yaw_rate_max_;
    double time_cost = std::max(t_trans, t_yaw);
    
    // Score terms
    double cov_term = static_cast<double>(vp.coverage) / coverage_scale_;
    double size_term = static_cast<double>(cluster.size) / size_scale_;
    double time_term = time_cost / time_scale_;
    
    double costmap_term = 0.0;
    if (w_costmap_ > 0.0 && costmap_) {
      int cost = getCostmapValue(vp.position.x, vp.position.y);
      if (cost >= 0) costmap_term = static_cast<double>(cost) / costmap_scale_;
    }
    
    return (w_coverage_ * cov_term) + (w_size_ * size_term) 
           - (w_time_ * time_term) - (w_costmap_ * costmap_term);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SELECTION
  // ═══════════════════════════════════════════════════════════════════════════
  
  std::vector<Candidate> selectBestTargets(std::vector<Candidate>& candidates)
  {
    // Sort by score (descending)
    std::sort(candidates.begin(), candidates.end(),
              [](const Candidate& a, const Candidate& b) { return a.score > b.score; });
    
    int k = std::min(top_k_, static_cast<int>(candidates.size()));
    std::vector<Candidate> targets(candidates.begin(), candidates.begin() + k);
    
    // Hysteresis: keep previous best if new isn't significantly better
    if (hysteresis_enabled_ && have_last_best_) {
      if (targets.front().score <= last_best_.score * (1.0 + switch_margin_)) {
        // Check if old target still exists
        for (const auto& c : candidates) {
          if (c.cluster_id == last_best_.cluster_id && c.vp_index == last_best_.vp_index) {
            targets.front() = c;
            break;
          }
        }
      }
    }
    
    last_best_ = targets.front();
    have_last_best_ = true;
    
    return targets;
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // PUBLISHING
  // ═══════════════════════════════════════════════════════════════════════════
  
  void publishTour(const std::string& frame_id, const std::vector<Candidate>& targets)
  {
    exploration_planner::msg::ExplorationStatus status;
    status.header.stamp = now();
    status.header.frame_id = frame_id;
    status.state = exploration_planner::msg::ExplorationStatus::EXPLORING;
    
    auto cur_pos = current_pose_.pose.position;
    double total_dist = 0.0;
    geometry_msgs::msg::Point last = cur_pos;
    
    for (const auto& t : targets) {
      status.cluster_order.push_back(t.cluster_id);
      
      geometry_msgs::msg::PoseStamped wp;
      wp.header = status.header;
      wp.pose.position = t.position;
      wp.pose.orientation = yawToQuaternion(t.yaw);
      status.waypoints.push_back(wp);
      
      total_dist += distance2D(last, t.position);
      last = t.position;
    }
    
    status.total_waypoints = targets.size();
    status.current_waypoint_index = 0;
    status.current_target = status.waypoints.front();
    status.total_distance_remaining = total_dist;
    status.estimated_time_remaining = total_dist / v_max_;
    
    tour_pub_->publish(status);
    
    const auto& best = targets.front();
    RCLCPP_INFO(get_logger(), "Target: cluster=%u score=%.2f pos=(%.1f,%.1f) cov=%d",
                best.cluster_id, best.score, best.position.x, best.position.y, best.coverage);
  }
  
  void publishTargetPose(const std::string& frame_id, const Candidate& target)
  {
    geometry_msgs::msg::PoseStamped msg;
    msg.header.stamp = now();
    msg.header.frame_id = frame_id;
    msg.pose.position = target.position;
    msg.pose.orientation = yawToQuaternion(target.yaw);
    
    target_pub_->publish(msg);
  }
  
  void publishExplorationComplete(const std::string& frame_id)
  {
    exploration_planner::msg::ExplorationStatus status;
    status.header.stamp = now();
    status.header.frame_id = frame_id;
    status.state = exploration_planner::msg::ExplorationStatus::COMPLETED;
    tour_pub_->publish(status);
    
    RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 5000, "Exploration complete!");
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // NAV2 INTEGRATION
  // ═══════════════════════════════════════════════════════════════════════════
  
  void sendNav2Goal(const std::string& frame_id, const Candidate& target)
  {
    // Rate limiting
    if (!rateLimitOk()) return;
    
    // Build goal
    geometry_msgs::msg::PoseStamped goal;
    goal.header.stamp = now();
    goal.header.frame_id = frame_id;
    goal.pose.position = target.position;
    goal.pose.orientation = yawToQuaternion(target.yaw);
    
    // Check if significantly different
    if (!isGoalDifferent(goal)) return;
    
    // Check action server
    if (!nav_client_->wait_for_action_server(std::chrono::milliseconds(200))) {
      RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 2000, 
                           "Nav2 action server not available");
      return;
    }
    
    // Cancel previous goal
    cancelNav2Goal();
    
    // Send new goal
    NavigateToPose::Goal nav_goal;
    nav_goal.pose = goal;
    
    auto options = rclcpp_action::Client<NavigateToPose>::SendGoalOptions();
    
    options.goal_response_callback = [this](const GoalHandle::SharedPtr& handle) {
      if (handle) {
        goal_handle_ = handle;
        RCLCPP_INFO(get_logger(), "Nav2 goal accepted");
      } else {
        RCLCPP_WARN(get_logger(), "Nav2 goal rejected");
      }
    };
    
    options.result_callback = [this](const GoalHandle::WrappedResult& result) {
      RCLCPP_INFO(get_logger(), "Nav2 result: %d", static_cast<int>(result.code));
    };
    
    nav_client_->async_send_goal(nav_goal, options);
    
    last_send_time_ = now();
    last_sent_goal_ = goal;
    have_last_sent_ = true;
    
    RCLCPP_INFO(get_logger(), "Sent Nav2 goal: (%.1f, %.1f) yaw=%.0f°",
                goal.pose.position.x, goal.pose.position.y,
                getYaw(goal.pose.orientation) * 180.0 / M_PI);
  }
  
  void cancelNav2Goal()
  {
    if (goal_handle_) {
      nav_client_->async_cancel_goal(goal_handle_);
      goal_handle_ = nullptr;
    }
  }
  
  bool rateLimitOk() const
  {
    if (last_send_time_.nanoseconds() == 0) return true;
    return (now() - last_send_time_).seconds() >= nav2_min_period_;
  }
  
  bool isGoalDifferent(const geometry_msgs::msg::PoseStamped& goal) const
  {
    if (!have_last_sent_) return true;
    
    double dist = distance2D(goal.pose.position, last_sent_goal_.pose.position);
    double yaw_diff = angleDiff(getYaw(goal.pose.orientation), 
                                 getYaw(last_sent_goal_.pose.orientation));
    
    return (dist > nav2_pos_tol_) || (yaw_diff > nav2_yaw_tol_);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // COSTMAP UTILITIES
  // ═══════════════════════════════════════════════════════════════════════════
  
  int getCostmapValue(double wx, double wy) const
  {
    if (!costmap_ || costmap_->data.empty()) return -1;
    
    double res = costmap_->info.resolution;
    double ox = costmap_->info.origin.position.x;
    double oy = costmap_->info.origin.position.y;
    
    int gx = static_cast<int>((wx - ox) / res);
    int gy = static_cast<int>((wy - oy) / res);
    
    int w = costmap_->info.width;
    int h = costmap_->info.height;
    
    if (gx < 0 || gx >= w || gy < 0 || gy >= h) return -1;
    
    return static_cast<int>(costmap_->data[gy * w + gx]);
  }
  
  // Parameters
  double w_time_, w_coverage_, w_size_, w_costmap_;
  double coverage_scale_, size_scale_, time_scale_, costmap_scale_;
  int max_vp_per_cluster_, top_k_;
  bool use_vp_yaw_;
  double v_max_, yaw_rate_max_;
  bool hysteresis_enabled_;
  double switch_margin_;
  bool costmap_filter_enabled_;
  int costmap_lethal_threshold_;
  bool nav2_enable_;
  std::string nav2_action_name_;
  double nav2_min_period_, nav2_pos_tol_, nav2_yaw_tol_;
  
  // State
  geometry_msgs::msg::PoseStamped current_pose_;
  bool have_pose_ = false;
  bool exploration_active_ = false;
  Candidate last_best_;
  bool have_last_best_ = false;
  
  // Nav2 state
  GoalHandle::SharedPtr goal_handle_;
  rclcpp::Time last_send_time_{0, 0, RCL_ROS_TIME};
  geometry_msgs::msg::PoseStamped last_sent_goal_;
  bool have_last_sent_ = false;
  
  // Costmap
  nav_msgs::msg::OccupancyGrid::SharedPtr costmap_;
  
  // ROS interfaces
  rclcpp::Subscription<frontier_exploration::msg::FrontierArray>::SharedPtr clusters_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr costmap_sub_;
  
  rclcpp::Publisher<exploration_planner::msg::ExplorationStatus>::SharedPtr tour_pub_;
  rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr target_pub_;
  rclcpp::Publisher<frontier_exploration::msg::FrontierArray>::SharedPtr scored_pub_;
  
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr start_srv_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr stop_srv_;
  
  rclcpp_action::Client<NavigateToPose>::SharedPtr nav_client_;
};

}  // namespace exploration_planner

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<exploration_planner::GlobalTourPlannerNode>());
  rclcpp::shutdown();
  return 0;
}
