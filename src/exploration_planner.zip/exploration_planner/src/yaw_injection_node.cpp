/**
 * Yaw Injection Node
 * 
 * Nav2'den gelen path'e yaw injection uygular.
 * 
 * Input:
 *   /plan (nav_msgs/Path) - Nav2'den gelen raw path
 *   /exploration/target_pose (geometry_msgs/PoseStamped) - Hedef yaw bilgisi
 *   /odom (nav_msgs/Odometry) - Mevcut yaw için
 * 
 * Output:
 *   /exploration/path_with_yaw (nav_msgs/Path) - Yaw eklenmiş path
 * 
 * Yaw Dağılımı:
 *   - İlk X metre: current_yaw → movement_direction
 *   - Orta kısım: movement_direction (path yönü)
 *   - Son Y metre: movement_direction → target_yaw (frontier'a dön)
 */

#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/path.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include "exploration_planner/math_utils.hpp"

namespace exploration_planner
{

class YawInjectionNode : public rclcpp::Node
{
public:
  YawInjectionNode() : Node("yaw_injection_node")
  {
    // Parameters
    declare_parameter("initial_blend_distance", 1.0);
    declare_parameter("final_blend_distance", 2.5);
    
    initial_blend_dist_ = get_parameter("initial_blend_distance").as_double();
    final_blend_dist_ = get_parameter("final_blend_distance").as_double();
    
    // Subscribers
    path_sub_ = create_subscription<nav_msgs::msg::Path>(
      "/plan", rclcpp::QoS(1).transient_local(),
      std::bind(&YawInjectionNode::pathCallback, this, std::placeholders::_1));
    
    target_sub_ = create_subscription<geometry_msgs::msg::PoseStamped>(
      "/exploration/target_pose", 10,
      std::bind(&YawInjectionNode::targetCallback, this, std::placeholders::_1));
    
    odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
      "/odom", 10,
      std::bind(&YawInjectionNode::odomCallback, this, std::placeholders::_1));
    
    // Publisher
    path_pub_ = create_publisher<nav_msgs::msg::Path>(
      "/exploration/path_with_yaw", 10);
    
    RCLCPP_INFO(get_logger(), "Yaw Injection Node initialized");
    RCLCPP_INFO(get_logger(), "  Initial blend: %.1fm, Final blend: %.1fm",
                initial_blend_dist_, final_blend_dist_);
  }

private:
  void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    current_yaw_ = getYaw(msg->pose.pose.orientation);
    have_odom_ = true;
  }
  
  void targetCallback(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
  {
    target_pose_ = *msg;
    target_yaw_ = getYaw(msg->pose.orientation);
    have_target_ = true;
  }
  
  void pathCallback(const nav_msgs::msg::Path::SharedPtr msg)
  {
    if (!have_odom_) {
      RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 2000, "Waiting for odom...");
      return;
    }
    
    if (!have_target_) {
      RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 2000, "Waiting for target pose...");
      return;
    }
    
    if (msg->poses.empty()) {
      RCLCPP_WARN(get_logger(), "Received empty path");
      return;
    }
    
    // Yaw injection uygula
    auto injected_path = injectYaw(*msg);
    
    // Publish
    path_pub_->publish(injected_path);
    
    RCLCPP_INFO(get_logger(), "Published path with yaw: %zu poses", injected_path.poses.size());
  }
  
  nav_msgs::msg::Path injectYaw(const nav_msgs::msg::Path& raw_path)
  {
    nav_msgs::msg::Path result = raw_path;
    
    if (result.poses.size() < 2) {
      if (!result.poses.empty()) {
        result.poses.back().pose.orientation = yawToQuaternion(target_yaw_);
      }
      return result;
    }
    
    // Kümülatif mesafeleri hesapla
    std::vector<double> distances = computeCumulativeDistances(result);
    double total_length = distances.back();
    
    // Hareket yönünü hesapla
    double movement_yaw = computeMovementDirection(result);
    
    // Blend mesafelerini ayarla
    auto [initial_blend, final_blend] = adjustBlendDistances(total_length);
    
    // Her waypoint için yaw hesapla
    for (size_t i = 0; i < result.poses.size(); ++i) {
      double dist_from_start = distances[i];
      double dist_to_end = total_length - dist_from_start;
      
      double waypoint_yaw = computeWaypointYaw(
        i, result.poses.size(),
        dist_from_start, dist_to_end, total_length,
        initial_blend, final_blend,
        movement_yaw, result);
      
      result.poses[i].pose.orientation = yawToQuaternion(waypoint_yaw);
    }
    
    return result;
  }
  
  std::vector<double> computeCumulativeDistances(const nav_msgs::msg::Path& path)
  {
    std::vector<double> distances;
    distances.reserve(path.poses.size());
    distances.push_back(0.0);
    
    for (size_t i = 1; i < path.poses.size(); ++i) {
      double dx = path.poses[i].pose.position.x - path.poses[i-1].pose.position.x;
      double dy = path.poses[i].pose.position.y - path.poses[i-1].pose.position.y;
      distances.push_back(distances.back() + std::sqrt(dx*dx + dy*dy));
    }
    
    return distances;
  }
  
  double computeMovementDirection(const nav_msgs::msg::Path& path)
  {
    double dx = path.poses.back().pose.position.x - path.poses.front().pose.position.x;
    double dy = path.poses.back().pose.position.y - path.poses.front().pose.position.y;
    return std::atan2(dy, dx);
  }
  
  std::pair<double, double> adjustBlendDistances(double total_length)
  {
    double initial = initial_blend_dist_;
    double final = final_blend_dist_;
    
    if (total_length < initial + final) {
      if (total_length < 0.5) {
        return {0.0, total_length};
      }
      double scale = total_length / (initial + final);
      initial *= scale * 0.3;
      final *= scale * 0.7;
    }
    
    return {initial, final};
  }
  
  double computeWaypointYaw(
    size_t index, size_t total_points,
    double dist_from_start, double dist_to_end, double total_length,
    double initial_blend, double final_blend,
    double movement_yaw,
    const nav_msgs::msg::Path& path)
  {
    bool in_initial = (dist_from_start < initial_blend) && (initial_blend > 0.01);
    bool in_final = (dist_to_end < final_blend) && (final_blend > 0.01);
    
    if (in_initial && in_final) {
      // Çok kısa path - direkt blend
      double t = smoothstep(dist_from_start / total_length);
      return blendAngle(current_yaw_, target_yaw_, t);
    }
    
    if (in_initial) {
      // BAŞLANGIÇ: current_yaw → movement_yaw
      double t = smoothstep(dist_from_start / initial_blend);
      return blendAngle(current_yaw_, movement_yaw, t);
    }
    
    if (in_final) {
      // SON 2.5m: movement_yaw → target_yaw
      double t = smoothstep(1.0 - dist_to_end / final_blend);
      return blendAngle(movement_yaw, target_yaw_, t);
    }
    
    // ORTA: sonraki noktaya bak
    if (index + 1 < total_points) {
      double dx = path.poses[index+1].pose.position.x - path.poses[index].pose.position.x;
      double dy = path.poses[index+1].pose.position.y - path.poses[index].pose.position.y;
      return std::atan2(dy, dx);
    }
    
    return movement_yaw;
  }
  
  // Parameters
  double initial_blend_dist_;
  double final_blend_dist_;
  
  // State
  double current_yaw_ = 0.0;
  double target_yaw_ = 0.0;
  geometry_msgs::msg::PoseStamped target_pose_;
  bool have_odom_ = false;
  bool have_target_ = false;
  
  // ROS interfaces
  rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr path_sub_;
  rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr target_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;
};

}  // namespace exploration_planner

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<exploration_planner::YawInjectionNode>());
  rclcpp::shutdown();
  return 0;
}
