"""
Exploration with Nav2 Launch File

Launches:
1. Nav2 stack (planner, costmaps, lifecycle manager)
2. Global Tour Planner (frontier selection + Nav2 goal)
3. Yaw Injection (adds yaw to Nav2 path)
4. Path Follower (generates cmd_vel)

Required topics:
- /projected_map (nav_msgs/OccupancyGrid) - Global map
- /camera/depth/points (sensor_msgs/PointCloud2) - Depth camera
- /odom (nav_msgs/Odometry) - Robot pose
- /frontier_clusters_complete (FrontierArray) - Frontiers
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    pkg_dir = get_package_share_directory('exploration_planner')
    params_file = os.path.join(pkg_dir, 'config', 'params.yaml')
    
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    
    return LaunchDescription([
        # ════════════════════════════════════════════════════════════════════
        # ARGUMENTS
        # ════════════════════════════════════════════════════════════════════
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='Use simulation time'
        ),
        
        # ════════════════════════════════════════════════════════════════════
        # NAV2 PLANNER SERVER
        # ════════════════════════════════════════════════════════════════════
        Node(
            package='nav2_planner',
            executable='planner_server',
            name='planner_server',
            output='screen',
            parameters=[params_file, {'use_sim_time': use_sim_time}],
        ),
        
        # ════════════════════════════════════════════════════════════════════
        # GLOBAL COSTMAP
        # ════════════════════════════════════════════════════════════════════
        Node(
            package='nav2_costmap_2d',
            executable='nav2_costmap_2d',
            name='global_costmap',
            output='screen',
            parameters=[params_file, {'use_sim_time': use_sim_time}],
            remappings=[
                ('costmap', '/global_costmap/costmap'),
                ('costmap_raw', '/global_costmap/costmap_raw'),
            ],
        ),
        
        # ════════════════════════════════════════════════════════════════════
        # LOCAL COSTMAP
        # ════════════════════════════════════════════════════════════════════
        Node(
            package='nav2_costmap_2d',
            executable='nav2_costmap_2d',
            name='local_costmap',
            output='screen',
            parameters=[params_file, {'use_sim_time': use_sim_time}],
            remappings=[
                ('costmap', '/local_costmap/costmap'),
                ('costmap_raw', '/local_costmap/costmap_raw'),
            ],
        ),
        
        # ════════════════════════════════════════════════════════════════════
        # LIFECYCLE MANAGER
        # ════════════════════════════════════════════════════════════════════
        Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            name='lifecycle_manager_nav',
            output='screen',
            parameters=[
                {'use_sim_time': use_sim_time},
                {'autostart': True},
                {'node_names': [
                    'global_costmap',
                    'local_costmap',
                    'planner_server',
                ]},
            ],
        ),
        
        # ════════════════════════════════════════════════════════════════════
        # EXPLORATION NODES
        # ════════════════════════════════════════════════════════════════════
        
        # Global Tour Planner - Frontier selection + Nav2 goal
        Node(
            package='exploration_planner',
            executable='global_tour_planner_node',
            name='global_tour_planner',
            output='screen',
            parameters=[params_file, {'use_sim_time': use_sim_time}],
        ),
        
        # Yaw Injection - Add yaw to Nav2 path
        Node(
            package='exploration_planner',
            executable='yaw_injection_node',
            name='yaw_injection_node',
            output='screen',
            parameters=[params_file, {'use_sim_time': use_sim_time}],
        ),
        
        # Path Follower - Generate cmd_vel
        Node(
            package='exploration_planner',
            executable='path_follower_node',
            name='path_follower_node',
            output='screen',
            parameters=[params_file, {'use_sim_time': use_sim_time}],
        ),
    ])
